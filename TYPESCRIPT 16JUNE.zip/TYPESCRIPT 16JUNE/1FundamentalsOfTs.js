"use strict";
console.log('Good Morning User!!');
console.log('Happy Learning :)');
