"use strict";
// function scoped keyword 
function learningVar() {
    var message = 'Hello';
    console.log(message); //accessible 
}
learningVar();
//  console.log(message)  //ReferenceError: message is not defined
//Redeclaration & Reassignment - var 
var xVar = 1223;
var xVar = 135; ///Redeclaration 
xVar = 567; //Reassignment
console.log(xVar);
// Block Scoped -> block {}-> let & const 
{
    var x = 10;
    let y = 20;
    const z = 30;
    console.log(x, y, z);
}
console.log(x);
// console.log(y,z) //Cannot find name 'y','z'
// Redeclaration & Reassignment - let & const 
let xLet = 123;
// let xLet = 678; //Cannot redeclare block-scoped variable 'xLet'
xLet = 678;
console.log(xLet);
const xConst = 0.4;
// const xConst = 0.8 //Cannot redeclare block-scoped variable 'xConst'
//  xConst = 0.8 //Cannot assign to 'xConst' because it is a constant
