"use strict";
// string - '' , ""
let fName = 'John';
let lName = "William";
// template literals -> string interpolation ``
let message = `
Hello ${fName} ${lName}, 
Welcome to the session!`;
console.log(message);
console.log(typeof message); // string 
// number - int , float , hexadecimal.....exp...
let maxScore = 100;
let myScore = 99.5;
let exp = 2.56e3;
console.log(typeof exp);
//boolean - true/false 
let isAgree = true;
console.log(typeof isAgree);
//null & undefined 
let x = null;
console.log(typeof x); // object
let y;
console.log(typeof y); //undefined
console.log(x == y); // checks the value , not the data type -> loose 
console.log(x === y); // checks the value , data type -> strict 
// bigint -> big interger 
let distance = 6789n;
console.log(typeof distance);
// Symbol -> unique value 
let user1 = Symbol('user');
let user2 = Symbol('user');
console.log(user1 == user2); //false 
// SPECIAL -> 
//void -> function / method -> not returning 
function learningVoid() {
    console.log('this is not returning');
}
//any-> anything 
// it will not enforce type safety
let data;
data = 122;
data = 'shipra';
let data1; // i=implicit -> any data type 
data1 = 156;
data1 = 'p';
// unknown 
// it will enforce type safety
let value;
value = 12345;
value = 'this is unknown';
if (typeof value == 'string') {
    console.log(value.toUpperCase());
}
console.log(value.toUpperCase()); // type assertion 
// union 
let amount = 10000;
amount = 'Ten Thousand';
// never -> functions -> infinite loop / error 
function learningNever() {
    throw new Error('Error Type');
}
// user defined 
//array - [ele1,ele2,...]
//access/modify -> index , ele1-0, ele2-1...eleN - N-1 
let strArr = ['a', 'e', 'i', 'o', 'u'];
let numArr = [12, 34, 45];
let mixArr = [12, 'a']; // string|number
mixArr[2] = true;
numArr[3] = 89;
console.log(strArr, numArr);
// tuple 
let tup = ['a', 12, 'b', 13];
// tup[4]= 'hello' -> cannot change the length of an array 
// object - {key/property : value, key : value}
let user = {
    name: 'Sheetal',
    age: 25,
};
user.city = 'Gurugram';
console.log(user['name']);
console.log(user);
// date - new Date()
let current = new Date();
// enum 
var WeekDays;
(function (WeekDays) {
    WeekDays[WeekDays["Monday"] = 0] = "Monday";
    WeekDays[WeekDays["Tuesday"] = 1] = "Tuesday";
    WeekDays[WeekDays["Wednesday"] = 2] = "Wednesday";
    WeekDays[WeekDays["Thursday"] = 3] = "Thursday";
    WeekDays[WeekDays["Friday"] = 4] = "Friday";
})(WeekDays || (WeekDays = {}));
let today = WeekDays.Tuesday;
console.log(today);
var WeekEnds;
(function (WeekEnds) {
    WeekEnds["Saturday"] = "Sat";
    WeekEnds["Sunday"] = "Sun";
})(WeekEnds || (WeekEnds = {}));
let w = WeekEnds.Saturday;
console.log(`Weekend starts from ${w}`);
