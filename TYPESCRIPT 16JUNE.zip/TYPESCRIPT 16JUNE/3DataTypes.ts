// string - '' , ""
let fName : string = 'John';
let lName = "William";
// template literals -> string interpolation ``
let message = `
Hello ${fName} ${lName}, 
Welcome to the session!`
console.log(message);
console.log(typeof message) // string 

// number - int , float , hexadecimal.....exp...
let maxScore = 100;
let myScore = 99.5;
let exp = 2.56e3;
console.log(typeof exp);

//boolean - true/false 
let isAgree = true;
console.log(typeof isAgree)

//null & undefined 
let x = null;
console.log(typeof x) // object

let y;
console.log(typeof y)//undefined

console.log(x==y); // checks the value , not the data type -> loose 
console.log(x===y); // checks the value , data type -> strict 

// bigint -> big interger 
let distance = 6789n;
console.log(typeof distance);

// Symbol -> unique value 
let user1 = Symbol('user');
let user2 = Symbol('user');

console.log(user1 == user2)//false 

// SPECIAL -> 

//void -> function / method -> not returning 
function learningVoid():void{
    console.log('this is not returning')
}

//any-> anything 
// it will not enforce type safety
let data : any;
data = 122;
data = 'shipra'

let data1; // i=implicit -> any data type 
data1 = 156;
data1 = 'p';

// unknown 
// it will enforce type safety

let value : unknown;
value = 12345;
value = 'this is unknown'

if(typeof value == 'string'){
    console.log(value.toUpperCase())
}

console.log((value as string).toUpperCase()) // type assertion 

// union 
let  amount : string | number= 10000;
amount = 'Ten Thousand'

// never -> functions -> infinite loop / error 
function learningNever():never{
    throw new Error('Error Type')
}

// user defined 

//array - [ele1,ele2,...]
//access/modify -> index , ele1-0, ele2-1...eleN - N-1 
let strArr : string[] = ['a','e','i','o','u'];
let numArr : number[] = [12,34,45];
let mixArr : any[] = [12,'a']; // string|number
mixArr[2]= true;
numArr[3] = 89;
console.log(strArr,numArr);

// tuple 
let tup : [string,number,string,number] = ['a',12,'b',13];
// tup[4]= 'hello' -> cannot change the length of an array 

// object - {key/property : value, key : value}
let user : {name : string , age : number , city? : string} = {
    name : 'Sheetal',
    age : 25,
}

user.city = 'Gurugram';
console.log(user['name']);
console.log(user)

// date - new Date()
let current : Date = new Date()

// enum 
enum WeekDays{
    Monday,
    Tuesday,
    Wednesday,
    Thursday,
    Friday
}

let today : WeekDays = WeekDays.Tuesday;
console.log(today)

enum WeekEnds{
    Saturday = 'Sat',
    Sunday = 'Sun'
}

let w : WeekEnds = WeekEnds.Saturday;
console.log(`Weekend starts from ${w}`)
