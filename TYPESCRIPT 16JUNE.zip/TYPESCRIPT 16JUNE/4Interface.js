"use strict";
let user1 = {
    name: 'Sheetal',
    age: 25,
    city: 'Gurugram'
};
let user2 = {
    name: 'Amisha',
    age: 25,
    city: 'Bangalore'
};
let user3 = {
    name: 'Deepank',
    age: 25,
    city: 'Noida'
};
let emp = {
    name: 'Deepank',
    age: 25,
    city: 'Noida',
    empID: 1345672,
    greet: function () {
        console.log('Good Afternoon, have a nice day!');
    }
};
emp.greet();
