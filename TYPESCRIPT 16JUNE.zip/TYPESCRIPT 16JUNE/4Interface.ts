interface UserDataType{
    name : string , 
    age : number , 
    city? : string
}

// extends -> reuse the existing interface 
interface EmployeeInterface extends UserDataType{
    empID : number,
    greet : ()=>void
}

let user1 : UserDataType = {
    name : 'Sheetal',
    age : 25,
    city : 'Gurugram'
}

let user2 : UserDataType = {
    name : 'Amisha',
    age : 25,
    city : 'Bangalore'
}
let user3 :UserDataType = {
    name : 'Deepank',
    age : 25,
    city : 'Noida'
}

let emp : EmployeeInterface = {
     name : 'Deepank',
    age : 25,
    city : 'Noida',
    empID : 1345672,
    greet : function():void{
        console.log('Good Afternoon, have a nice day!')
    }
}

emp.greet()