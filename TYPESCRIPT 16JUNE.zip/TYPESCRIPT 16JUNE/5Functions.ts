// define the function 
function UserDetails(username : string , experience : number):string{
    return `
    ** USER DETAILS **
    Username : ${username}
    Experience : ${experience} years
    `
}
console.log(UserDetails('Rohit',7))
console.log(UserDetails('Rohan',8))

// FUNCTION EXPRESSION 

let greeting = function(name : string):void{
    console.log(`Hello ${name}, Good Day!!`)
}
greeting('Hrithik')

// ARROW FUNCTION 
let cube = (num : number):void => console.log(`The cube of ${num} is ${num**3}.
    `);

cube(24)

// regular function : global object / window object 

// function learningThis(){
//     console.log(this) // global object 
// }

//arrow function : don't have any this value {}
let learningThis = ()=>{
    console.log(this) // {}
}

learningThis()

//>> method inside an object : refer to that object only 

let emp : {name : string, greet : ()=>void}={
    name : 'Akash',
    greet : function(){
            console.log(`Hello ${this.name}, have a nice day`)
    }
}
emp.greet()