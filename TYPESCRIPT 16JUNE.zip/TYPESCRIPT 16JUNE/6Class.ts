class Student{
    StudName : string;
    StudID : number;
    Course : string;

    constructor(name : string ,id : number , course : string ){
        this.StudName = name;
        this.StudID = id;
        this.Course = course;

    }

    Message(){
        console.log(`Hello ${this.StudName}, You have successfully enrolled in ${this.Course} course`)
    }
}

let student1 = new Student('Rohit',12, 'Angular');
console.log(student1)
student1.Message()

let student2 = new Student('Rohan',13, 'ReactJS');
console.log(student2)
student2.Message()

//INHERITANCE 
class TopTenStudent extends Student {
    Rank : number;

    constructor(name : string ,id : number , course : string, rank : number){
      // call the constructor method of parent class   
      super(name,id,course);
      this.Rank = rank;
    }
//OVERIDDING 
    Message(){
        console.log(`Congratulations ${this.StudName}, You are in top ${this.Rank}!!`);
        //call the parent class method 
        super.Message();
    }
}
let student3 = new TopTenStudent('Amisha',14,'Angular',3);
console.log(student3)
student3.Message()