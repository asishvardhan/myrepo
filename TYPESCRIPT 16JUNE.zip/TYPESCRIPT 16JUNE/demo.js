// regular function : global object / window object 

// function learningThis(){
//     console.log(this) // global object 
// }

//arrow function : don't have any this value {}
let learningThis = ()=>{
    console.log(this) // {}
}

learningThis()

//>> method inside an object : refer to that object only 

let emp ={
    name : 'Akash',
    greet : function(){
            console.log(`Hello ${this.name}, have a nice day`)
    }
}
emp.greet()